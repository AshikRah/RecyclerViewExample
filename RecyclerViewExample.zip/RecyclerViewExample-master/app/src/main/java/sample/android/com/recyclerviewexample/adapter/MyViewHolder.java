package sample.android.com.recyclerviewexample.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import sample.android.com.recyclerviewexample.R;

public class MyViewHolder extends RecyclerView.ViewHolder {

    TextView name, eduBackground;

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);

        name = itemView.findViewById(R.id._title);
        eduBackground = itemView.findViewById(R.id._desc);

        Log.i("test", "ViewHolder");

    }
}

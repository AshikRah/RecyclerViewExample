package sample.android.com.recyclerviewexample.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import sample.android.com.recyclerviewexample.R;
import sample.android.com.recyclerviewexample.model.Student;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.MyViewHolder2> {


    private Context context;
    private List<Student> studentList;

    public RVAdapter(Context context, List<Student> studentList) {
        this.context = context;
        this.studentList = studentList;
    }

    @NonNull
    @Override
    public MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {


        final View view = LayoutInflater.from(context).inflate(R.layout.sample_layout, null);

        //   MyViewHolder holder = new MyViewHolder(view);


        Log.i("test", "onCreate View");
        return new MyViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 myViewHolder, int i) {

        myViewHolder.name.setText(studentList.get(i).getName());
        myViewHolder.eduBackground.setText(studentList.get(i).getEduBackground());

        Log.i("test", "onBindView");
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }



    //   inser view holder class
    public class MyViewHolder2 extends RecyclerView.ViewHolder {

        TextView name, eduBackground;

        public MyViewHolder2(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id._title);
            eduBackground = itemView.findViewById(R.id._desc);

            Log.i("test", "ViewHolder");


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Toast.makeText(context, "" + studentList.get(getAdapterPosition()).getName(), Toast.LENGTH_SHORT).show();
                }
            });


        }
    }


}

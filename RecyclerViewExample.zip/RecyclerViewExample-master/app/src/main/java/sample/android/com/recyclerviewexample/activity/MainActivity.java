package sample.android.com.recyclerviewexample.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;

import java.util.ArrayList;
import java.util.List;

import sample.android.com.recyclerviewexample.R;
import sample.android.com.recyclerviewexample.adapter.RVAdapter;
import sample.android.com.recyclerviewexample.model.Student;

public class MainActivity extends AppCompatActivity {


    private RecyclerView recyclerView;
    private List<Student> studentList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
        loadData();
    }

    private void loadData() {

        String[] name = getResources().getStringArray(R.array.student);
        String[] edu = getResources().getStringArray(R.array.edu);

        for (int i = 0; i < name.length; i++) {

            Student student = new Student(name[i], edu[i]);
            studentList.add(student);

        }

        RVAdapter rvAdapter = new RVAdapter(this, studentList);


        //    LinearLayoutManager
      /*  LinearLayoutManager manager = new LinearLayoutManager(this);
        manager.setOrientation(LinearLayoutManager.HORIZONTAL);   //  for horizontal*/

      // GridLayoutManager
      /*  GridLayoutManager manager = new GridLayoutManager(this, 2);

        manager.setOrientation(LinearLayoutManager.HORIZONTAL);   //  for horizontal

        */

      //  StaggeredLayoutManager
        StaggeredGridLayoutManager manager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);

        recyclerView.setLayoutManager(manager);

        recyclerView.setAdapter(rvAdapter);


    }

    private void initView() {

        recyclerView = findViewById(R.id.rvId);

    }
}
